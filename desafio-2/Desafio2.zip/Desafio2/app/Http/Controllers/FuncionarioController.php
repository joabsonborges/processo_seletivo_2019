<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB; // para usar a classe DB

class FuncionarioController extends Controller
{
	// Listando funcionario
    public function lista()
    {
    	return DB::table('funcionario')
    		->get();
    }

    // Cadastrando Pessoa
    public function novo(Request $request)
    {
    	$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw

    	return DB::table('funcionario')
    		->insertGetId($data);
    }

    // Editando funcionario
	public function editar($id, Request $request){
		$data = sizeof($_POST) > 0 ? $_POST : json_decode($request->getContent(), true); // Pega o post ou o raw
 
		$res = DB::table('funcionario')
			->where('id',$id)
			->update($data);
 
		return ["status" => ($res)?'ok':'erro'];
	}

	// Excluindo funcionario
	public function excluir($id)
	{
		$res = DB::table('funcionario')
			-> where('id',$id)
			-> delete();
			
		return ["status" => ($res)?'ok':'erro'];
	}
}