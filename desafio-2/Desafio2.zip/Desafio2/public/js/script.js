//Carousel Opinião
$('.box-carousel-opiniao').owlCarousel({
    loop:false,
    autoplay: true,
    margin:10,
    nav:false,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})

$('.box-carousel-galeria').owlCarousel({
    loop:false,
    margin:10,
    autoplay: true,
    nav:false,
    dots: false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})
//Lista estática com busca usando JavaScript
function filter() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("input");
    filter = input.value.toUpperCase();
    ul = document.getElementById("ul");
    li = ul.getElementsByTagName("li");


    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (!input.value) {
            li[i].style.display = "none";
        } else if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "block";
        } else {
            li[i].style.display = "none";
        }

    }
}

//carousel noticias home
$('.carousel-noticias-home').owlCarousel({
    loop:false,
    margin:10,
    nav:false,
    dots: true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
})

//fecha radio

$(document).ready(function(){
    var video_1 = document.getElementById("video-1");
    var video_2 = document.getElementById("video-2");

    video_1.pause();
    video_2.pause();

    $(".btn-fechar-radio").click(function(){
        if($(this).attr("data-acao") == "fechar") {
            $( ".box-radio-ao-vivo" ).slideUp("slow");
            $(".svg-seta-baixar-dims").css("transform","rotate(180deg)");
            $(this).attr("data-acao", "abrir");
        } else {
            $( ".box-radio-ao-vivo" ).slideDown("slow");
            $(".svg-seta-baixar-dims").css("transform","rotate(0deg)");
            $(this).attr("data-acao", "fechar");
        }
    });
})




//tootipe

$('[data-toggle="tooltip"]').tooltip()


//time Line

$(".item-timeline:even").addClass("item-timeline-reverso");

setTimeout(function(){
    $('.alert').fadeOut();
}, 3*1000)


function video_lead_play_state(element, active)
{
    var $active = $(element).closest(".js-video-lead").find(".btn-play-active");
    var $default = $(element).closest(".js-video-lead").find(".btn-play-default");

    if (active) {
        $active.show();
        $default.hide();
    } else {
        $active.hide();
        $default.show();
    }
}


$(document).ready(function() {
    $('#link_video').hide();
    $('#format').change(function() {
        if ($('#format').val() == 'video') {
            $('#link_video').show();
        } else {
            $('#link_video').hide();
        }
    });
});

$(document).ready(function() {
    $("#format option:selected").each(function(){
        var formato = $(this).val();
        if(formato == 'imagem'){
            $('#image').show();
        }
        else{
            $('#image').hide();
        }
    });

    $('#format').change(function() {
        if ($('#format').val() == 'imagem') {
            $('#image').show();
        } else {
            $('#image').hide();
        }
    });
});

$(document).ready(function(){
    setInterval(() => {
        atualizaFeed();
    }, 40000)
});

function atualizaFeed(){
    $.ajax({
        type: 'GET',
        url: '/getPosts',
        dataType: "Html",
        // contentType: "application/json; charset=utf-8",
        cache: false,
        beforeSend: function(){
            $("#ultimas-noticias").html("Carregando...");
        },
        error: function(){
            $("#ultimas-noticias").html("Algum erro ocorreu aqui!");
        },
        success: function(posts){
            $(".ultimas-noticias").html(posts);
        }
    });
}


// function isYoutubeVideo(url){
//     var v = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
//     return (url.match(v)) ? RegExp.$1 : false;
// }

// function validaVideo(url) {
//     var urlvideo = document.getElementById('link_video').value;
//     var codvideo = isYoutubeVideo(urlvideo);

//     if (!codvideo){
//         alert('Link do vídeo inválido!');
//     }
// }
