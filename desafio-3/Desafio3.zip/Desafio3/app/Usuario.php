<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
  protected $fillable = [
    'usuario_nome',
    'usuario_email',
    'usuario_dataNascimento'
    'senha'
    'usuario_qtd'
  ];
}
