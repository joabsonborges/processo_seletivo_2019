@extends('layout')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Add Usuario:
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('usuarios.store') }}">
          <div class="form-group">
              {{ csrf_field() }}
              <label for="name">Nome:</label>
              <input type="text" class="form-control" name="usuario_nome"/>
          </div>
          <div class="form-group">
              <label for="price"> Email:</label>
              <input type="text" class="form-control" name="usuario_email"/>
          </div>
           <div class="form-group">
              <label for="price"> Data Nascimento:</label>
              <input type="text" class="form-control" name="usuario_dataNascimento"/>
          </div>
          <div class="form-group">
              <label for="price"> Senha:</label>
              <input type="text" class="form-control" name="senha"/>
          </div>
          <div class="form-group">
              <label for="quantity">Usuario Qtd:</label>
              <input type="text" class="form-control" name="usuario_qtd"/>
          </div>
          <button type="submit" class="btn btn-primary">Add</button>
      </form>
  </div>
</div>
@endsection