@extends('layout')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Editar Usuario:
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('usuarios.update', $usuario->id) }}">
        @method('PATCH')
        @csrf
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" name="usuario_nome" value={{ $usuario->usuario_nome }} />
        </div>
        <div class="form-group">
          <label for="price">Email:</label>
          <input type="text" class="form-control" name="usuario_email" value={{ $usuario->usuario_email }} />
        </div>
        <div class="form-group">
          <label for="price">Data Nascimento:</label>
          <input type="text" class="form-control" name="usuario_dataNascimento" value={{ $usuario->usuario_dataNascimento }} />
        </div>
        <div class="form-group">
          <label for="price">Senha:</label>
          <input type="text" class="form-control" name="senha" value={{ $usuario->senha }} />
        </div>
        <div class="form-group">
          <label for="quantity">Usuario Qtd:</label>
          <input type="text" class="form-control" name="usuario_qtd" value={{ $usuario->usuario_qtd }} />
        </div>
        <button type="submit" class="btn btn-primary">Atualizar</button>
      </form>
  </div>
</div>
@endsection